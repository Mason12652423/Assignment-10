"""main.py - Entry point. Run with:  uv run main.py   (or: python main.py)"""
from auth import auth_menu
from database import Database
from game import Game
import ui


def main():
    db = Database()
    try:
        while True:
            username = auth_menu(db)
            if username is None:
                break
            Game(db, username).start()
    except (KeyboardInterrupt, EOFError):
        print()
    ui.info("Thanks for playing. Goodbye!")


if __name__ == "__main__":
    main()
