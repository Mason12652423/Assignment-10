"""game.py - The Game class: ties every module together and runs the main loop."""
import random

import quest
import ui
from combat import Combat
from game_map import MAPS
from monster import Dragon
from npc import NPCS
from player import Player
from skill import ALL_SKILLS

INTRO = [
    "Long ago, the Ancient Dragon slept beneath the mountains beyond Darkwood Forest.",
    "Now it has awoken. Its shadow falls across the land, and goblins, wolves and",
    "slimes pour out of the woods to serve it. The peaceful village of Willowbrook",
    "is the first in its path.",
    "",
    "You are a wandering adventurer who has just arrived at its gates.",
    "Elder Mira is waiting. Perhaps you are the hero this village needs...",
]

HELP = ("Move: W/A/S/D (you can type several like 'ddds') | I inventory | C character | "
        "K skills | Q quests | H help | X save & exit")


class Game:
    def __init__(self, db, username):
        self.db = db
        self.username = username
        self.player = None
        self.running = True
        self.notice = ""     # message shown under the map after the next redraw

    # ---------------- startup / shutdown ----------------
    def start(self):
        try:
            self._load_or_create()
            if self.player:
                self._loop()
        except (KeyboardInterrupt, EOFError):
            print()
            ui.warn("Interrupted - saving your progress...")
        if self.player:
            self.save()
            ui.good("Game saved.")

    def _load_or_create(self):
        data = self.db.load_game(self.username)
        player = None
        if data:
            try:
                player = Player.from_dict(data)
            except (KeyError, ValueError, TypeError):
                ui.warn("Your save file was damaged. Starting a new game.")
        if player is None:
            self.player = Player(self.username)
            self._intro()
            self.save()
        elif player.won:
            ui.good("You already saved Willowbrook!")
            print("1) Start a new game  2) Back to menu")
            if ui.ask_number("Choice: ", 1, 2) == 1:
                self.player = Player(self.username)
                self._intro()
                self.save()
        else:
            self.player = player
            ui.good(f"Welcome back, {player.name}! Continuing your adventure.")
        if self.player:
            self._fix_location()

    def _fix_location(self):
        """Guard against bad saved coordinates."""
        p = self.player
        if p.map_key not in MAPS or not MAPS[p.map_key].is_walkable(p.x, p.y):
            p.map_key = p.map_key if p.map_key in MAPS else "village"
            p.x, p.y = MAPS[p.map_key].start

    def _intro(self):
        ui.clear()
        ui.header("THE DRAGON'S SHADOW")
        for line in INTRO:
            ui.slow_print(line, 0.015)
        print()
        ui.pause()

    def save(self):
        self.db.save_game(self.username, self.player.to_dict())

    @property
    def map(self):
        return MAPS[self.player.map_key]

    # ---------------- main loop ----------------
    def _loop(self):
        while self.running:
            self._draw()
            raw = ui.ask("> ").lower()
            if raw:
                self._handle(raw)

    def _draw(self):
        p = self.player
        ui.clear()
        ui.header(self.map.name)
        print(f"{ui.cyan(p.name)}  Lv {p.level}  HP {ui.hp_bar(p.hp, p.max_hp, 15)}  {ui.gold(p.gold)}")
        boss_alive = quest.state(p, "main") != quest.COMPLETED
        for line in self.map.render(p.x, p.y, NPCS, boss_alive):
            print(" " + line)
        print(f" {ui.player_symbol()} you  {ui.blue('X')} NPC  {ui.magenta('>')} portal  "
              f"{ui.red('D')} dragon  {ui.green('T')} tree  {ui.gray('#')} wall")
        if self.notice:
            print("\n" + self.notice)
            self.notice = ""
        print("\n" + ui.gray(HELP))

    def _handle(self, raw):
        if set(raw) <= set("wasd"):
            deltas = {"w": (0, -1), "s": (0, 1), "a": (-1, 0), "d": (1, 0)}
            for ch in raw:
                if self._move(*deltas[ch]) != "moved":
                    break
            return
        commands = {"i": self._inventory, "c": self._character, "k": self._skills,
                    "q": self._quests, "h": self._help, "x": self._exit}
        if raw in commands:
            commands[raw]()
        else:
            self.notice = ui.yellow("Unknown command. Type H for help.")

    # ---------------- movement ----------------
    def _move(self, dx, dy):
        """Try to step. Returns 'moved' or 'stop' (anything that should end a multi-step)."""
        p, m = self.player, self.map
        nx, ny = p.x + dx, p.y + dy

        if (nx, ny) in m.npcs:                         # walking into an NPC = talk
            NPCS[m.npcs[(nx, ny)]].interact(self)
            ui.pause()
            self.save()
            return "stop"
        if (nx, ny) == m.boss_pos and quest.state(p, "main") != quest.COMPLETED:
            self._boss_fight()
            return "stop"
        if (nx, ny) in m.portals:
            self._use_portal(m.portals[(nx, ny)])
            return "stop"
        if not m.is_walkable(nx, ny):
            self.notice = ui.yellow("Something blocks your way.")
            return "stop"

        p.x, p.y = nx, ny
        if m.encounter_rate and random.random() < m.encounter_rate:
            self._fight(m.random_monster())
            return "stop"
        return "moved"

    def _use_portal(self, portal):
        p = self.player
        if portal.requires and not p.inventory.has(portal.requires):
            self.notice = ui.yellow(f"The gate is locked. You need: {portal.requires}.")
            return
        p.map_key, p.x, p.y = portal.target_map, portal.x, portal.y
        msgs = quest.notify(p, "enter", self.map.name)
        self.save()
        self.notice = ui.cyan(f"You travel to {self.map.name}.")
        if msgs:
            self.notice += "\n" + "\n".join(msgs)

    # ---------------- combat ----------------
    def _fight(self, monster):
        ui.clear()
        ui.warn(f"A wild {monster.name} appears!")
        result = Combat(self.player, monster).run()
        if result == "lose":
            self._respawn()
        self.save()
        ui.pause()

    def _boss_fight(self):
        ui.clear()
        ui.bad("The Ancient Dragon rises from its hoard and roars!")
        result = Combat(self.player, Dragon()).run()
        if result == "lose":
            self._respawn()
        elif quest.state(self.player, "main") == quest.COMPLETED:
            self._victory()
        self.save()
        ui.pause()

    def _respawn(self):
        p = self.player
        lost = p.gold // 2
        p.gold -= lost
        p.hp = max(1, p.max_hp // 2)
        p.map_key = "village"
        p.x, p.y = MAPS["village"].start
        ui.warn(f"You wake up in Willowbrook. You lost {lost} gold.")

    def _victory(self):
        self.player.won = True
        ui.header("VICTORY!")
        for line in ["The Ancient Dragon crashes to the ground and the shadow lifts from the land.",
                     "Willowbrook cheers your name. You are the Hero of the Dragon's Shadow!",
                     "", "THE END. Thanks for playing!"]:
            ui.slow_print(line, 0.02)
        self.running = False

    # ---------------- menus ----------------
    def _inventory(self):
        ui.header("INVENTORY")
        print(f"Gold: {ui.gold(self.player.gold)}")
        while self.player.inventory.use_menu(self.player) is not None:
            print(f"HP: {ui.hp_bar(self.player.hp, self.player.max_hp)}")
        ui.pause()
        self.save()

    def _character(self):
        p = self.player
        ui.header("CHARACTER")
        print(f"Name:    {ui.cyan(p.name)}")
        print(f"Level:   {p.level}")
        print(f"XP:      {ui.magenta(f'{p.xp}/{p.xp_needed}')}")
        print(f"HP:      {ui.hp_bar(p.hp, p.max_hp)}")
        print(f"Attack:  {p.attack}    Defense: {p.defense}")
        print(f"Gold:    {ui.gold(p.gold)}")
        print(f"Skills:  {', '.join(ui.cyan(s) for s in p.skills)}")
        inv = ", ".join(f"{ui.item(n)} x{c}" for n, c in sorted(p.inventory.items.items()))
        print(f"Items:   {inv or 'none'}")
        print(f"Location: {self.map.name} ({p.x}, {p.y})")
        ui.pause()

    def _skills(self):
        ui.header("SKILLS")
        for name in self.player.skills:
            s = ALL_SKILLS[name]
            print(f" {ui.cyan(s.name)} (cooldown {s.cooldown}) - {s.description}")
        ui.info("Learn more skills from Trainer Kael in the village.")
        ui.pause()

    def _quests(self):
        ui.header("QUEST LOG")
        quest.show_log(self.player)
        ui.pause()

    def _help(self):
        ui.header("HELP")
        print("Walk into NPCs to talk to them. Walk onto '>' to travel between maps.")
        print("Random monsters appear when you walk in the forest and the dragon's lair.")
        print("Your game auto-saves often; X saves and returns to the login menu.")
        print(HELP)
        ui.pause()

    def _exit(self):
        self.save()
        self.running = False
