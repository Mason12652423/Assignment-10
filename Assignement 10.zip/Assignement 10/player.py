"""player.py - The Player class and how it converts to/from a JSON-friendly dict."""
from inventory import Inventory
from skill import ALL_SKILLS
import ui


class Player:
    def __init__(self, name):
        self.name = name
        self.level = 1
        self.xp = 0
        self.max_hp = 60
        self.hp = 60
        self.attack = 8
        self.defense = 2
        self.gold = 30
        self.inventory = Inventory({"Health Potion": 2})
        self.skills = ["Power Strike"]
        self.map_key = "village"
        self.x, self.y = 8, 5
        self.quests = {}        # {quest_id: {"status", "step", "progress"}}
        self.won = False
        self.guarded = False    # combat-only flag, NOT saved

    @property
    def xp_needed(self):
        return self.level * 40

    @property
    def is_alive(self):
        return self.hp > 0

    def gain_xp(self, amount):
        """Add XP, handle level-ups. Returns a list of messages."""
        self.xp += amount
        msgs = []
        while self.xp >= self.xp_needed:
            self.xp -= self.xp_needed
            self.level += 1
            self.max_hp += 12
            self.attack += 2
            self.defense += 1
            self.hp = self.max_hp
            msgs.append(ui.yellow(f"*** LEVEL UP! You are now level {self.level}! HP/ATK/DEF increased. ***"))
        return msgs

    def heal(self, amount):
        before = self.hp
        self.hp = min(self.max_hp, self.hp + amount)
        return self.hp - before

    def take_damage(self, raw, pierce=False):
        dmg = raw if pierce else raw - self.defense
        dmg = max(1, dmg)
        if self.guarded:
            dmg = max(1, dmg // 2)
            self.guarded = False
        self.hp = max(0, self.hp - dmg)
        return dmg

    def learn_skill(self, name):
        if name not in self.skills:
            self.skills.append(name)

    # ---------- saving / loading ----------
    def to_dict(self):
        """Only plain types (str/int/bool/list/dict) so TinyDB can store it as JSON."""
        return {
            "name": self.name, "level": self.level, "xp": self.xp,
            "hp": self.hp, "max_hp": self.max_hp,
            "attack": self.attack, "defense": self.defense, "gold": self.gold,
            "inventory": self.inventory.to_dict(),
            "skills": list(self.skills),
            "map": self.map_key, "x": self.x, "y": self.y,
            "quests": self.quests, "won": self.won,
        }

    @classmethod
    def from_dict(cls, d):
        p = cls(d["name"])
        p.level = int(d["level"]); p.xp = int(d["xp"])
        p.max_hp = int(d["max_hp"]); p.hp = max(1, min(int(d["hp"]), p.max_hp))
        p.attack = int(d["attack"]); p.defense = int(d["defense"]); p.gold = int(d["gold"])
        p.inventory = Inventory.from_dict(d.get("inventory"))
        p.skills = [s for s in d.get("skills", ["Power Strike"]) if s in ALL_SKILLS] or ["Power Strike"]
        p.map_key = d.get("map", "village")
        p.x, p.y = int(d.get("x", 8)), int(d.get("y", 5))
        p.quests = dict(d.get("quests", {}))
        p.won = bool(d.get("won", False))
        return p
