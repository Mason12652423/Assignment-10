"""inventory.py - Inventory stores {item_name: count}. A plain dict saves cleanly to JSON."""
import ui
from item import ITEMS, get_item


class Inventory:
    def __init__(self, items=None):
        self.items = dict(items or {})

    def add(self, name, qty=1):
        self.items[name] = self.items.get(name, 0) + qty

    def remove(self, name, qty=1):
        if self.count(name) < qty:
            return False
        self.items[name] -= qty
        if self.items[name] <= 0:
            del self.items[name]  # never keep zero-count entries
        return True

    def count(self, name):
        return self.items.get(name, 0)

    def has(self, name, qty=1):
        return self.count(name) >= qty

    def names(self):
        return sorted(self.items)

    def show(self):
        if not self.items:
            ui.warn("Your bag is empty.")
            return
        for i, name in enumerate(self.names(), 1):
            it = get_item(name)
            print(f" {i}. {ui.item(name)} x{self.items[name]} - {it.description}")

    def use_menu(self, player):
        """Pick an item to use. Returns None if cancelled, True if consumed, False if not."""
        names = self.names()
        if not names:
            ui.warn("Your bag is empty.")
            return None
        self.show()
        choice = ui.ask_number("Use which item? (0 to cancel): ", 0, len(names))
        if choice == 0:
            return None
        name = names[choice - 1]
        consumed, message = get_item(name).use(player)
        print(message)
        if consumed:
            self.remove(name)
        return consumed

    def to_dict(self):
        return dict(self.items)

    @classmethod
    def from_dict(cls, data):
        # keep only known items with valid positive integer counts
        clean = {k: v for k, v in (data or {}).items()
                 if isinstance(v, int) and v > 0 and k in ITEMS}
        return cls(clean)
