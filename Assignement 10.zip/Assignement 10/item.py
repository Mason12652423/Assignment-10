"""item.py - Item classes. Item is the parent; Potion, Tonic and KeyItem inherit from it."""
import ui


class Item:
    """Base class. use() returns (was_consumed, message)."""

    def __init__(self, name, description, price=0):
        self.name = name
        self.description = description
        self.price = price  # 0 means it cannot be bought/sold

    @property
    def sellable(self):
        return self.price > 0

    def use(self, player):
        return False, "You can't use that right now."


class Potion(Item):
    """Heals HP."""

    def __init__(self, name, description, price, heal):
        super().__init__(name, description, price)
        self.heal = heal

    def use(self, player):
        if player.hp >= player.max_hp:
            return False, "You are already at full health."
        healed = player.heal(self.heal)
        return True, f"You drink the {ui.item(self.name)} and recover {ui.green(str(healed))} HP."


class Tonic(Item):
    """Permanently raises attack."""

    def __init__(self, name, description, price, attack_bonus):
        super().__init__(name, description, price)
        self.attack_bonus = attack_bonus

    def use(self, player):
        player.attack += self.attack_bonus
        return True, f"You drink the {ui.item(self.name)}. Attack permanently +{self.attack_bonus}!"


class KeyItem(Item):
    """Quest items: cannot be used or sold (price 0)."""

    def __init__(self, name, description):
        super().__init__(name, description, 0)

    def use(self, player):
        return False, "This item is needed for a quest."


ITEMS = {i.name: i for i in [
    Potion("Health Potion", "Restores 30 HP.", 15, 30),
    Potion("Greater Health Potion", "Restores 80 HP.", 40, 80),
    Tonic("Attack Tonic", "Permanently +2 attack.", 80, 2),
    Item("Wolf Fang", "A sharp fang. Herbalists pay well for these.", 6),
    KeyItem("Dungeon Key", "A heavy iron key that opens the gate to the Dragon's Lair."),
]}


def get_item(name):
    return ITEMS[name]
