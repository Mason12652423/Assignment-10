"""quest.py - Quest data + the logic that tracks progress.

Quest progress lives on the player as plain data so it saves to JSON:
    player.quests = {"main": {"status": "active", "step": 1, "progress": 0}, ...}
  status   : "active" or "completed" (a quest not in the dict is "not_started")
  step     : index of the current step in Quest.steps
  progress : how many of the current step's `count` are done (kills, visits...)

Game events call notify(player, kind, target):
  kind "kill"  -> a monster died      kind "talk"  -> player talked to an NPC
  kind "enter" -> player entered a map
A step is finished when kind+target match and progress reaches count. "collect" steps
are checked when the player talks to the step's `npc` (items are handed in).
"""
import ui

NOT_STARTED, ACTIVE, COMPLETED = "not_started", "active", "completed"


class Step:
    def __init__(self, kind, target, count, text, npc=None, reward_item=None):
        self.kind, self.target, self.count, self.text = kind, target, count, text
        self.npc = npc                  # turn-in NPC for "collect" steps
        self.reward_item = reward_item  # item given when this step completes


class Quest:
    def __init__(self, qid, name, description, steps, reward_gold=0, reward_xp=0,
                 reward_items=None, is_main=False):
        self.qid, self.name, self.description, self.steps = qid, name, description, steps
        self.reward_gold, self.reward_xp = reward_gold, reward_xp
        self.reward_items = reward_items or {}
        self.is_main = is_main


QUESTS = {q.qid: q for q in [
    Quest("main", "The Dragon's Shadow", "Stop the Ancient Dragon before it destroys Willowbrook.", [
        Step("kill", "Goblin", 3, "Defeat 3 Goblins in Darkwood Forest."),
        Step("talk", "Blacksmith Brom", 1, "Visit Blacksmith Brom in the village.",
             reward_item="Dungeon Key"),
        Step("enter", "Dragon's Lair", 1, "Unlock the gate in east Darkwood Forest and enter the Dragon's Lair."),
        Step("kill", "Ancient Dragon", 1, "Defeat the Ancient Dragon!"),
    ], reward_gold=500, reward_xp=200, is_main=True),
    Quest("slime", "Slime Trouble", "Farmer Tom's fields are overrun with slimes.", [
        Step("kill", "Slime", 3, "Defeat 3 Slimes."),
    ], reward_gold=60, reward_xp=50),
    Quest("fangs", "Wolf Fangs", "Lyra needs wolf fangs for her medicine.", [
        Step("collect", "Wolf Fang", 2, "Bring 2 Wolf Fangs to Herbalist Lyra.", npc="Herbalist Lyra"),
    ], reward_gold=20, reward_xp=60, reward_items={"Greater Health Potion": 2}),
]}


def state(player, qid):
    entry = player.quests.get(qid)
    return entry["status"] if entry else NOT_STARTED


def current_step(player, qid):
    return QUESTS[qid].steps[player.quests[qid]["step"]]


def start(player, qid):
    player.quests[qid] = {"status": ACTIVE, "step": 0, "progress": 0}
    q = QUESTS[qid]
    return [ui.magenta(f"New quest: {q.name}"), ui.magenta(f"  Goal: {q.steps[0].text}")]


def notify(player, kind, target):
    """Tell every active quest that something happened. Returns messages to print."""
    msgs = []
    for qid, entry in list(player.quests.items()):
        if entry["status"] != ACTIVE:
            continue
        quest = QUESTS[qid]
        step = quest.steps[entry["step"]]

        if step.kind == "collect":
            if kind == "talk" and target == step.npc:
                have = player.inventory.count(step.target)
                if have >= step.count:
                    player.inventory.remove(step.target, step.count)
                    msgs += _advance(player, quest, entry, step)
                else:
                    msgs.append(ui.yellow(f"[{quest.name}] You have {have}/{step.count} {step.target}."))
        elif step.kind == kind and step.target == target:
            entry["progress"] += 1
            if entry["progress"] >= step.count:
                msgs += _advance(player, quest, entry, step)
            else:
                msgs.append(ui.magenta(f"[{quest.name}] {step.target}: {entry['progress']}/{step.count}"))
    return msgs


def _advance(player, quest, entry, step):
    msgs = [ui.green(f"Quest step complete: {step.text}")]
    if step.reward_item:
        player.inventory.add(step.reward_item)
        msgs.append(f"You received: {ui.item(step.reward_item)}")
    entry["step"] += 1
    entry["progress"] = 0
    if entry["step"] >= len(quest.steps):
        entry["status"] = COMPLETED
        msgs.append(ui.green(f"*** QUEST COMPLETE: {quest.name} ***"))
        player.gold += quest.reward_gold
        msgs.append(f"Reward: {ui.gold(quest.reward_gold)}, {ui.xp(quest.reward_xp)}")
        for name, qty in quest.reward_items.items():
            player.inventory.add(name, qty)
            msgs.append(f"Reward: {qty}x {ui.item(name)}")
        msgs += player.gain_xp(quest.reward_xp)
    else:
        msgs.append(ui.magenta(f"New objective: {quest.steps[entry['step']].text}"))
    return msgs


def show_log(player):
    """Print the quest log."""
    if not player.quests:
        ui.warn("You have no quests yet. Talk to the villagers!")
        return
    ordered = sorted(player.quests, key=lambda q: not QUESTS[q].is_main)
    for qid in ordered:
        quest, entry = QUESTS[qid], player.quests[qid]
        tag = ui.red("[MAIN]") if quest.is_main else ui.cyan("[SIDE]")
        if entry["status"] == COMPLETED:
            print(f"{tag} {quest.name} - {ui.green('completed')}")
            continue
        step = quest.steps[entry["step"]]
        if step.kind == "collect":
            prog = f"{min(player.inventory.count(step.target), step.count)}/{step.count}"
        else:
            prog = f"{entry['progress']}/{step.count}"
        print(f"{tag} {quest.name} - step {entry['step'] + 1}/{len(quest.steps)}")
        print(f"      {step.text} ({prog})")
