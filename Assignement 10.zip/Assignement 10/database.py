"""database.py - All TinyDB access lives here (the rest of the game never touches TinyDB).

TinyDB stores everything in one JSON file (game_db.json) with two tables:

  accounts: {"username": "bob", "salt": "<hex>", "password_hash": "<hex>"}
  saves:    {"username": "bob", "data": { ...Player.to_dict()... }}

JSON was chosen because TinyDB is a JSON document store: we save plain dicts/lists/
numbers/strings, which is why Player.to_dict() converts objects (Inventory, etc.)
into simple types first.
"""
from tinydb import Query, TinyDB


class Database:
    def __init__(self, path="game_db.json"):
        self.db = TinyDB(path)
        self.accounts = self.db.table("accounts")
        self.saves = self.db.table("saves")

    # ---- accounts ----
    def get_account(self, username):
        return self.accounts.get(Query().username == username.lower())

    def create_account(self, username, salt, password_hash):
        self.accounts.insert({"username": username.lower(), "salt": salt,
                              "password_hash": password_hash})

    # ---- game saves ----
    def save_game(self, username, data):
        """upsert = update the row if it exists, otherwise insert it."""
        self.saves.upsert({"username": username.lower(), "data": data},
                          Query().username == username.lower())

    def load_game(self, username):
        row = self.saves.get(Query().username == username.lower())
        return row["data"] if row else None

    def delete_save(self, username):
        self.saves.remove(Query().username == username.lower())
