"""auth.py - Registration and login.

Passwords are never stored. Registration creates a random salt and stores
pbkdf2_hmac(password, salt). Login recomputes the hash with the stored salt and
compares it to the stored hash.
"""
import getpass
import hashlib
import hmac
import re
import secrets

import ui

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,16}$")


def hash_password(password, salt_hex=None):
    salt_hex = salt_hex or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), 100_000)
    return salt_hex, digest.hex()


def _read_password(prompt):
    try:
        return getpass.getpass(prompt)   # hides typing
    except (EOFError, KeyboardInterrupt):
        raise
    except Exception:
        return ui.ask(prompt)


def register(db):
    ui.header("REGISTER")
    while True:
        username = ui.ask("Choose a username (3-16 letters/numbers/_, blank to cancel): ")
        if not username:
            return None
        if not USERNAME_RE.match(username):
            ui.warn("Invalid username. Use 3-16 letters, numbers or underscores.")
        elif db.get_account(username):
            ui.warn("That username is taken.")
        else:
            break
    while True:
        password = _read_password("Choose a password (min 6 chars): ")
        if len(password) < 6:
            ui.warn("Password too short.")
            continue
        if password != _read_password("Repeat password: "):
            ui.warn("Passwords do not match.")
            continue
        break
    salt, pw_hash = hash_password(password)
    db.create_account(username, salt, pw_hash)
    ui.good("Account created!")
    return username.lower()


def login(db):
    ui.header("LOGIN")
    for attempt in range(3):
        username = ui.ask("Username (blank to cancel): ")
        if not username:
            return None
        password = _read_password("Password: ")
        account = db.get_account(username)
        if account:
            _, attempt_hash = hash_password(password, account["salt"])
            if hmac.compare_digest(attempt_hash, account["password_hash"]):
                ui.good(f"Welcome back, {username}!")
                return username.lower()
        ui.warn(f"Wrong username or password. ({2 - attempt} attempts left)")
    return None


def auth_menu(db):
    """Returns a logged-in username, or None if the player quits."""
    while True:
        ui.header("TERMINAL RPG: THE DRAGON'S SHADOW")
        print("1) Login\n2) Register\n3) Quit")
        choice = ui.ask_number("Choice: ", 1, 3)
        if choice == 3:
            return None
        username = login(db) if choice == 1 else register(db)
        if username:
            return username
