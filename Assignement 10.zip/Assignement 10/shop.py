"""shop.py - Buy and sell items for gold."""
import ui
from item import get_item


class Shop:
    def __init__(self, name, stock):
        self.name = name
        self.stock = stock  # list of item names

    def open(self, player):
        while True:
            ui.header(self.name)
            print(f"Your gold: {ui.gold(player.gold)}")
            print("1) Buy   2) Sell   0) Leave")
            choice = ui.ask_number("Choice: ", 0, 2)
            if choice == 0:
                return
            self._buy(player) if choice == 1 else self._sell(player)

    def _buy(self, player):
        for i, name in enumerate(self.stock, 1):
            it = get_item(name)
            print(f" {i}. {ui.item(name)} - {ui.gold(it.price)} - {it.description}")
        choice = ui.ask_number("Buy which item? (0 to go back): ", 0, len(self.stock))
        if choice == 0:
            return
        it = get_item(self.stock[choice - 1])
        qty = ui.ask_number("How many? (1-99): ", 1, 99)
        cost = it.price * qty
        if player.gold < cost:
            ui.warn(f"Not enough gold! That costs {cost}.")
            return
        player.gold -= cost
        player.inventory.add(it.name, qty)
        ui.good(f"Bought {qty}x {it.name} for {cost} gold.")

    def _sell(self, player):
        sellable = [n for n in player.inventory.names() if get_item(n).sellable]
        if not sellable:
            ui.warn("You have nothing to sell.")
            return
        for i, name in enumerate(sellable, 1):
            print(f" {i}. {ui.item(name)} x{player.inventory.count(name)} - sells for {ui.gold(get_item(name).price // 2)} each")
        choice = ui.ask_number("Sell which item? (0 to go back): ", 0, len(sellable))
        if choice == 0:
            return
        name = sellable[choice - 1]
        qty = ui.ask_number(f"How many? (1-{player.inventory.count(name)}): ", 1, player.inventory.count(name))
        player.inventory.remove(name, qty)
        earned = get_item(name).price // 2 * qty
        player.gold += earned
        ui.good(f"Sold {qty}x {name} for {earned} gold.")
