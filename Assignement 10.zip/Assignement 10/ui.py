"""ui.py - Colors and safe input helpers used by every other file.

Color legend used across the game:
  green   = health / good news       red     = damage / danger / monsters
  yellow  = gold / prompts / warnings  cyan  = items and info
  magenta = XP / quests / portals     blue   = NPCs
"""
import os
import sys
import time

from colorama import Fore, Style, init

init()  # makes colors work on Windows terminals too


def paint(text, color, bold=False):
    """Wrap text in a color code and reset afterwards."""
    return f"{Style.BRIGHT if bold else ''}{color}{text}{Style.RESET_ALL}"


def red(t): return paint(t, Fore.RED, True)
def green(t): return paint(t, Fore.GREEN)
def yellow(t): return paint(t, Fore.YELLOW)
def cyan(t): return paint(t, Fore.CYAN)
def magenta(t): return paint(t, Fore.MAGENTA)
def blue(t): return paint(t, Fore.LIGHTBLUE_EX, True)
def gray(t): return paint(t, Fore.LIGHTBLACK_EX)
def water(t): return paint(t, Fore.LIGHTBLUE_EX)
def player_symbol(): return paint("@", Fore.LIGHTYELLOW_EX, True)


def gold(n): return paint(f"{n} gold", Fore.YELLOW, True)
def xp(n): return paint(f"{n} XP", Fore.MAGENTA, True)
def item(name): return paint(name, Fore.CYAN, True)
def npc(name): return blue(name)


def header(title):
    line = "=" * 50
    print()
    print(yellow(line))
    print(paint(title.center(50), Fore.YELLOW, True))
    print(yellow(line))


def say(text): print(text)
def good(text): print(green(text))
def bad(text): print(red(text))
def warn(text): print(yellow(text))
def info(text): print(cyan(text))


def slow_print(text, delay=0.02):
    """Typewriter effect for story text."""
    for ch in paint(text, Fore.MAGENTA):
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(delay)
    print()


def hp_bar(cur, mx, width=20):
    """Colored bar like [#########-----] 45/90 (green > 50%, yellow > 25%, else red)."""
    mx = max(1, mx)
    cur = max(0, min(cur, mx))
    filled = round(width * cur / mx)
    ratio = cur / mx
    color = Fore.GREEN if ratio > 0.5 else Fore.YELLOW if ratio > 0.25 else Fore.RED
    return paint("[" + "#" * filled + "-" * (width - filled) + "]", color) + f" {cur}/{mx}"


def clear():
    os.system("cls" if os.name == "nt" else "clear")


# ---------- input helpers: they keep asking until the answer is valid ----------

def ask(prompt):
    return input(paint(prompt, Fore.YELLOW)).strip()


def ask_number(prompt, lo, hi):
    """Ask for an integer between lo and hi (inclusive)."""
    while True:
        raw = ask(prompt)
        try:
            value = int(raw)
        except ValueError:
            warn(f"Please enter a number from {lo} to {hi}.")
            continue
        if lo <= value <= hi:
            return value
        warn(f"Please enter a number from {lo} to {hi}.")


def ask_yes_no(prompt):
    while True:
        raw = ask(prompt + " (y/n): ").lower()
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        warn("Please answer y or n.")


def pause():
    ask("(press Enter to continue) ")
