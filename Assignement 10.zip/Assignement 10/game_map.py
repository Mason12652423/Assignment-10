"""game_map.py - Map layouts, portals, NPC positions and monster spawns.

Tile legend:  #  wall   ~  water   T  tree   .  walkable floor
NPCs, portals and the boss are NOT in the grid; they are stored by (x, y) in dicts
so the grid stays simple. The player cannot walk through #, ~ or T.
"""
import random

import ui
from monster import Dragon, Goblin, Orc, Skeleton, Slime, Wolf

WALKABLE = "."


class Portal:
    def __init__(self, target_map, x, y, requires=None):
        self.target_map, self.x, self.y = target_map, x, y   # where you arrive
        self.requires = requires                               # item needed to pass


class GameMap:
    def __init__(self, key, name, rows, start, npcs=None, portals=None,
                 spawns=None, encounter_rate=0.0, boss_pos=None):
        widths = {len(r) for r in rows}
        assert len(widths) == 1, f"Map {key}: rows have different lengths {widths}"
        self.key, self.name, self.rows, self.start = key, name, rows, start
        self.npcs = npcs or {}              # {(x, y): npc_name}
        self.portals = portals or {}        # {(x, y): Portal}
        self.spawns = spawns or []          # monster classes that can appear
        self.encounter_rate = encounter_rate
        self.boss_pos = boss_pos
        self.width, self.height = len(rows[0]), len(rows)

    def is_walkable(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height and self.rows[y][x] == WALKABLE

    def random_monster(self):
        return random.choice(self.spawns)()

    def render(self, px, py, npc_registry, boss_alive):
        """Return the map as a list of colored strings."""
        lines = []
        for y, row in enumerate(self.rows):
            out = ""
            for x, ch in enumerate(row):
                pos = (x, y)
                if pos == (px, py):
                    out += ui.player_symbol()
                elif pos in self.npcs:
                    out += ui.blue(npc_registry[self.npcs[pos]].symbol)
                elif pos in self.portals:
                    out += ui.magenta(">")
                elif boss_alive and pos == self.boss_pos:
                    out += ui.red("D")
                elif ch == "#":
                    out += ui.gray("#")
                elif ch == "~":
                    out += ui.water("~")
                elif ch == "T":
                    out += ui.green("T")
                else:
                    out += ui.gray(".")
            lines.append(out)
        return lines


VILLAGE_ROWS = [
    "############################",
    "#..........#######.........#",
    "#..........#.....#.........#",
    "#....TT....#.....#....~~...#",
    "#....TT....###.###....~~...#",
    "#..........................#",
    "#..####.......~~...........#",
    "#..#..#.......~~...###.....#",
    "#..#..#....................#",
    "#..#.##...............TT...#",
    "#...........................",
    "#..........................#",
    "############################",
]

FOREST_ROWS = [
    "##############################",
    "#....TTT.......~~~.......TT..#",
    "#....TTT.......~~~.......TT..#",
    "#..........TT.........~~.....#",
    "#.######...TT...####..~~..TT.#",
    "#.#....#.......#..#.......TT.#",
    "..#.....................T....#",
    "#.#....#...~~..#..#.......TT.#",
    "#.######...~~..####.........##",
    "#...........TT.....~~........#",
    "#..TT.......TT.....~~..TT....#",
    "#..TT..................TT....." ,
    "##############################",
]

DUNGEON_ROWS = [
    "##########################",
    "#....#..........#........#",
    "#....#..##..##..#........#",
    "#....#..##..##..#...##...#",
    "..........................",
    "######.####..#####.#######",
    "#....#.#........#........#",
    "#....#.#..#..#..#........#",
    "#......#..#..#..#........#",
    "#....#....#..#..#........#",
    "##########################",
]

MAPS = {
    "village": GameMap(
        "village", "Willowbrook Village", VILLAGE_ROWS, start=(8, 5),
        npcs={(14, 2): "Elder Mira", (9, 8): "Blacksmith Brom", (21, 2): "Farmer Tom",
              (5, 7): "Herbalist Lyra", (24, 6): "Merchant Gale", (25, 9): "Trainer Kael"},
        portals={(27, 10): Portal("forest", 1, 6)},
    ),
    "forest": GameMap(
        "forest", "Darkwood Forest", FOREST_ROWS, start=(1, 6),
        portals={(0, 6): Portal("village", 26, 10),
                 (29, 11): Portal("dungeon", 1, 4, requires="Dungeon Key")},
        spawns=[Slime, Goblin, Wolf], encounter_rate=0.14,
    ),
    "dungeon": GameMap(
        "dungeon", "Dragon's Lair", DUNGEON_ROWS, start=(1, 4),
        portals={(0, 4): Portal("forest", 28, 11)},
        spawns=[Skeleton, Orc], encounter_rate=0.14, boss_pos=(22, 9),
    ),
}
