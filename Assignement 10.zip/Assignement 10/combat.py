"""combat.py - Turn-based battle between a Player and a Monster."""
import random

import quest
import ui
from skill import ALL_SKILLS


class Combat:
    def __init__(self, player, monster):
        self.player = player
        self.monster = monster
        self.cooldowns = {}   # skill name -> turns remaining (resets every battle)
        self.turn = 0

    def run(self):
        """Fight until someone wins. Returns 'win', 'lose' or 'fled'."""
        p, m = self.player, self.monster
        p.guarded = False
        ui.header(f"BATTLE: {m.name}" + (" (BOSS)" if m.is_boss else ""))
        while True:
            self.turn += 1
            self._show_status()
            if self._player_turn() == "fled":
                return "fled"
            if not m.is_alive:
                return self._victory()

            poison = m.tick_status()
            if poison:
                print(poison)
                if not m.is_alive:
                    return self._victory()

            for line in m.act(p, self.turn):
                print(line)
            if not p.is_alive:
                return self._defeat()
            self._tick_cooldowns()

    def _show_status(self):
        p, m = self.player, self.monster
        print()
        print(f"{ui.red(m.name):<22} {ui.hp_bar(m.hp, m.max_hp)}" +
              (ui.green(f"  (poisoned {m.poison_turns})") if m.poison_turns else ""))
        print(f"{ui.cyan(p.name):<22} {ui.hp_bar(p.hp, p.max_hp)}")

    def _player_turn(self):
        """Loop until the player does something that uses up the turn."""
        p, m = self.player, self.monster
        while True:
            print("\n1) Attack  2) Skill  3) Item  4) Run")
            choice = ui.ask_number("Your move: ", 1, 4)
            if choice == 1:
                dmg = m.take_damage(p.attack + random.randint(-2, 3))
                print(f"You strike the {m.name} for {ui.red(str(dmg))} damage.")
                return "acted"
            if choice == 2:
                if self._use_skill():
                    return "acted"
            elif choice == 3:
                if p.inventory.use_menu(p) is True:
                    return "acted"
            else:
                if m.is_boss:
                    ui.warn("You cannot run from a boss!")
                    continue
                if random.random() < 0.5:
                    ui.good("You escaped!")
                    return "fled"
                ui.warn("You failed to escape!")
                return "acted"

    def _use_skill(self):
        """Returns True if a skill was used."""
        p = self.player
        skills = [ALL_SKILLS[n] for n in p.skills]
        for i, s in enumerate(skills, 1):
            cd = self.cooldowns.get(s.name, 0)
            status = ui.green("ready") if cd == 0 else ui.red(f"cooldown {cd}")
            print(f" {i}. {ui.cyan(s.name)} ({status}) - {s.description}")
        choice = ui.ask_number("Use which skill? (0 to go back): ", 0, len(skills))
        if choice == 0:
            return False
        skill = skills[choice - 1]
        if self.cooldowns.get(skill.name, 0) > 0:
            ui.warn(f"{skill.name} is still on cooldown!")
            return False
        print(skill.use(p, self.monster))
        # +1 because the end-of-round tick happens right after use
        self.cooldowns[skill.name] = skill.cooldown + 1
        return True

    def _tick_cooldowns(self):
        for name in list(self.cooldowns):
            self.cooldowns[name] = max(0, self.cooldowns[name] - 1)

    def _victory(self):
        p, m = self.player, self.monster
        gold, drops = m.roll_loot()
        p.gold += gold
        print(ui.green(f"\nYou defeated the {m.name}!"))
        print(f"You gain {ui.xp(m.xp)} and {ui.gold(gold)}.")
        for name in drops:
            p.inventory.add(name)
            print(f"The {m.name} dropped: {ui.item(name)}!")
        for line in p.gain_xp(m.xp):
            print(line)
        for line in quest.notify(p, "kill", m.name):
            print(line)
        return "win"

    def _defeat(self):
        ui.bad(f"\nThe {self.monster.name} has defeated you...")
        return "lose"
