"""npc.py - NPC classes. ShopKeeper and Trainer inherit from NPC.

Dialogue is a dict: {state_key: [lines]}. The state key is chosen from the NPC's quest:
  "not_started", "active:<step number>", "active", "completed", or "default".
"""
import quest
import ui
from shop import Shop
from skill import ALL_SKILLS


class NPC:
    def __init__(self, name, symbol, lines, quest_id=None, offers_quest=False):
        self.name = name
        self.symbol = symbol
        self.lines = lines
        self.quest_id = quest_id          # quest used to pick dialogue
        self.offers_quest = offers_quest  # does this NPC give that quest?

    def _dialogue_key(self, player):
        if not self.quest_id:
            return "default"
        st = quest.state(player, self.quest_id)
        if st == quest.ACTIVE:
            specific = f"active:{player.quests[self.quest_id]['step']}"
            return specific if specific in self.lines else "active"
        return st

    def interact(self, game):
        player = game.player
        ui.header(self.name)
        key = self._dialogue_key(player)
        for line in self.lines.get(key, self.lines["default"]):
            print(f"{ui.npc(self.name)}: {line}")

        just_started = False
        if self.offers_quest and quest.state(player, self.quest_id) == quest.NOT_STARTED:
            print()
            if ui.ask_yes_no("Accept this quest?"):
                for msg in quest.start(player, self.quest_id):
                    print(msg)
                just_started = True
            else:
                ui.warn("Maybe next time.")
        if not just_started:
            for msg in quest.notify(player, "talk", self.name):
                print(msg)


class ShopKeeper(NPC):
    def __init__(self, name, symbol, lines, shop):
        super().__init__(name, symbol, lines)
        self.shop = shop

    def interact(self, game):
        super().interact(game)
        if ui.ask_yes_no("Browse the shop?"):
            self.shop.open(game.player)


class Trainer(NPC):
    def interact(self, game):
        super().interact(game)
        if ui.ask_yes_no("Learn new skills?"):
            self._teach(game.player)

    def _teach(self, player):
        while True:
            available = [s for s in ALL_SKILLS.values() if s.name not in player.skills]
            if not available:
                ui.good("You already know every skill I can teach!")
                return
            print(f"\nYour gold: {ui.gold(player.gold)}  |  Level: {player.level}")
            for i, s in enumerate(available, 1):
                print(f" {i}. {ui.cyan(s.name)} - {ui.gold(s.learn_cost)}, needs level {s.min_level}, "
                      f"cooldown {s.cooldown} - {s.description}")
            choice = ui.ask_number("Learn which skill? (0 to leave): ", 0, len(available))
            if choice == 0:
                return
            skill = available[choice - 1]
            if player.level < skill.min_level:
                ui.warn(f"You need level {skill.min_level} for {skill.name}.")
            elif player.gold < skill.learn_cost:
                ui.warn("Not enough gold.")
            else:
                player.gold -= skill.learn_cost
                player.learn_skill(skill.name)
                ui.good(f"You learned {skill.name}!")


NPCS = {n.name: n for n in [
    NPC("Elder Mira", "M", {
        "not_started": [
            "Traveler... the Ancient Dragon has awoken in the cave beyond Darkwood Forest.",
            "Goblins already roam the woods, serving its shadow. Will you help us?",
        ],
        "active:0": ["Goblins swarm the forest. Defeat three of them, then return to the village."],
        "active:1": ["Well done! Go and see Brom the blacksmith. He has something you'll need."],
        "active:2": ["The gate is in the east of Darkwood Forest. Be brave."],
        "active:3": ["The dragon waits in the deepest chamber. The whole village believes in you."],
        "completed": ["You saved Willowbrook! Our hero!"],
        "default": ["Welcome, traveler."],
    }, quest_id="main", offers_quest=True),

    NPC("Blacksmith Brom", "B", {
        "not_started": ["*clang clang* Hmph. Elder Mira has a job for you if you're brave. Talk to her."],
        "active:0": ["Those goblins are dangerous. Come back once you've thinned out the pack."],
        "active:1": ["So you're the goblin-slayer! Take this key. It opens the Dragon's Lair gate."],
        "active": ["Keep your blade sharp, friend. And drink potions early, not late!"],
        "completed": ["A dragon-slayer in my shop! Ha! Drinks are on me."],
        "default": ["*clang clang*"],
    }, quest_id="main"),

    NPC("Farmer Tom", "F", {
        "not_started": ["Oh no, my poor crops! Slimes are everywhere in the forest.",
                        "Could you squish three of them for me?"],
        "active": ["Still slimes out there... 3 of them, please! They're bouncing on my cabbages!"],
        "completed": ["The fields are safe thanks to you. Have a cabbage! ...No? Okay."],
        "default": ["Hello there!"],
    }, quest_id="slime", offers_quest=True),

    NPC("Herbalist Lyra", "H", {
        "not_started": ["Shh, I'm brewing. Wolves in the forest drop fangs that make great medicine.",
                        "Bring me two Wolf Fangs and I'll reward you."],
        "active": ["Two Wolf Fangs, dear. Wolves hide in Darkwood Forest."],
        "completed": ["Those fangs worked wonders. Stay healthy out there!"],
        "default": ["Hello."],
    }, quest_id="fangs", offers_quest=True),

    ShopKeeper("Merchant Gale", "G", {
        "default": ["Step right up! Potions, tonics, anything a hero needs. Gold talks, friend!"],
    }, Shop("Gale's General Store", ["Health Potion", "Greater Health Potion", "Attack Tonic"])),

    Trainer("Trainer Kael", "K", {
        "default": ["Strength is skill, not just muscle. Reach higher levels and I'll teach you powerful techniques."],
    }),
]}
