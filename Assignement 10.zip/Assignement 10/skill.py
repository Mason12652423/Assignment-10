"""skill.py - Skill is the parent class; each skill subclass overrides use().

Every skill has its own cooldown (turns before it can be used again), a gold price
to learn at the trainer and a minimum level.
"""
import random

import ui


class Skill:
    name = "Skill"
    description = ""
    cooldown = 1
    learn_cost = 0
    min_level = 1

    def use(self, user, target):
        """Apply the effect and return a message. Subclasses MUST override this."""
        raise NotImplementedError


class PowerStrike(Skill):
    name = "Power Strike"
    description = "A heavy blow: 160% attack damage."
    cooldown = 2
    learn_cost = 0  # starting skill
    min_level = 1

    def use(self, user, target):
        raw = int(user.attack * 1.6) + random.randint(0, 3)
        dmg = target.take_damage(raw)
        return f"You unleash {ui.cyan(self.name)} on the {target.name} for {ui.red(str(dmg))} damage!"


class Fireball(Skill):
    name = "Fireball"
    description = "Magic fire that ignores defense. Damage grows with level."
    cooldown = 3
    learn_cost = 60
    min_level = 2

    def use(self, user, target):
        dmg = target.take_damage(14 + 4 * user.level, pierce=True)
        return f"You hurl a {ui.red('Fireball')} at the {target.name} for {ui.red(str(dmg))} damage!"


class Heal(Skill):
    name = "Heal"
    description = "Restore 25 + 5 x level HP."
    cooldown = 4
    learn_cost = 50
    min_level = 2

    def use(self, user, target):
        healed = user.heal(25 + 5 * user.level)
        return f"You cast {ui.green('Heal')} and recover {ui.green(str(healed))} HP."


class PoisonSting(Skill):
    name = "Poison Sting"
    description = "Small hit + poison for 3 turns."
    cooldown = 4
    learn_cost = 70
    min_level = 3

    def use(self, user, target):
        dmg = target.take_damage(int(user.attack * 0.5))
        target.poison_turns = 3
        target.poison_dmg = 4 + user.level
        return (f"You sting the {target.name} for {ui.red(str(dmg))} and {ui.green('poison')} it "
                f"({target.poison_dmg} dmg for 3 turns)!")


class IronGuard(Skill):
    name = "Iron Guard"
    description = "Halve the damage of the next hit you take."
    cooldown = 3
    learn_cost = 40
    min_level = 2

    def use(self, user, target):
        user.guarded = True
        return f"You raise {ui.cyan('Iron Guard')}. The next hit will hurt less."


# Registry: skill name -> skill object. The player's save stores only the NAMES.
ALL_SKILLS = {s.name: s for s in [PowerStrike(), Fireball(), Heal(), PoisonSting(), IronGuard()]}
