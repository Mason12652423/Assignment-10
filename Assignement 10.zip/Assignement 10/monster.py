"""monster.py - Monster is the parent class. Each subclass changes stats and/or act().

Boss inherits from Monster, and Dragon inherits from Boss (two levels of inheritance).
"""
import random

import ui


class Monster:
    name = "Monster"
    max_hp = 20
    attack = 5
    defense = 0
    xp = 10
    gold_range = (1, 5)
    drops = []          # list of (item_name, chance 0-1)
    is_boss = False

    def __init__(self):
        self.hp = self.max_hp
        self.poison_turns = 0
        self.poison_dmg = 0

    @property
    def is_alive(self):
        return self.hp > 0

    def take_damage(self, raw, pierce=False):
        """pierce=True ignores defense. Always deals at least 1."""
        dmg = raw if pierce else raw - self.defense
        dmg = max(1, dmg)
        self.hp = max(0, self.hp - dmg)
        return dmg

    def tick_status(self):
        """Apply poison at the start of the monster's turn."""
        if self.poison_turns > 0 and self.is_alive:
            self.hp = max(0, self.hp - self.poison_dmg)
            self.poison_turns -= 1
            return ui.green(f"Poison hurts the {self.name} for {self.poison_dmg} damage!")
        return None

    def hit(self, player, multiplier=1.0):
        raw = int(self.attack * multiplier) + random.randint(-2, 2)
        return player.take_damage(raw)

    def act(self, player, turn):
        """The monster's turn. Returns a list of messages. Subclasses override."""
        dmg = self.hit(player)
        return [f"The {ui.red(self.name)} hits you for {ui.red(str(dmg))} damage."]

    def roll_loot(self):
        gold = random.randint(*self.gold_range)
        items = [name for name, chance in self.drops if random.random() < chance]
        return gold, items


class Slime(Monster):
    name = "Slime"
    max_hp, attack, defense, xp = 20, 5, 0, 12
    gold_range = (3, 8)
    drops = [("Health Potion", 0.15)]

    def act(self, player, turn):
        if random.random() < 0.25:  # sometimes regenerates instead of attacking
            self.hp = min(self.max_hp, self.hp + 5)
            return [f"The {ui.red('Slime')} jiggles and regenerates 5 HP."]
        return super().act(player, turn)


class Goblin(Monster):
    name = "Goblin"
    max_hp, attack, defense, xp = 30, 8, 1, 20
    gold_range = (5, 12)
    drops = [("Health Potion", 0.20)]

    def act(self, player, turn):
        msgs = super().act(player, turn)
        if player.gold > 0 and random.random() < 0.2:  # sneaky thief
            stolen = min(3, player.gold)
            player.gold -= stolen
            msgs.append(ui.yellow(f"The Goblin snatches {stolen} gold from your pocket!"))
        return msgs


class Wolf(Monster):
    name = "Wolf"
    max_hp, attack, defense, xp = 35, 10, 1, 25
    gold_range = (4, 10)
    drops = [("Wolf Fang", 0.6)]

    def act(self, player, turn):
        msgs = super().act(player, turn)
        if random.random() < 0.3:  # fast: sometimes bites twice
            dmg = self.hit(player, 0.7)
            msgs.append(f"The {ui.red('Wolf')} bites again for {ui.red(str(dmg))} damage!")
        return msgs


class Skeleton(Monster):
    name = "Skeleton"
    max_hp, attack, defense, xp = 50, 12, 4, 40
    gold_range = (10, 20)
    drops = [("Greater Health Potion", 0.2)]


class Orc(Monster):
    name = "Orc"
    max_hp, attack, defense, xp = 70, 16, 3, 60
    gold_range = (15, 30)
    drops = [("Greater Health Potion", 0.25), ("Attack Tonic", 0.15)]

    def act(self, player, turn):
        if turn % 3 == 0:  # every third turn: heavy smash
            dmg = self.hit(player, 1.5)
            return [f"The {ui.red('Orc')} SMASHES you for {ui.red(str(dmg))} damage!"]
        return super().act(player, turn)


class Boss(Monster):
    """Base for bosses: cannot be fled from."""
    is_boss = True


class Dragon(Boss):
    name = "Ancient Dragon"
    max_hp, attack, defense, xp = 180, 20, 6, 500
    gold_range = (200, 200)
    drops = [("Greater Health Potion", 1.0)]

    def act(self, player, turn):
        if turn % 3 == 0:
            dmg = self.hit(player, 1.8)
            return [ui.red(f"The Ancient Dragon unleashes FIRE BREATH for {dmg} damage!")]
        return super().act(player, turn)
